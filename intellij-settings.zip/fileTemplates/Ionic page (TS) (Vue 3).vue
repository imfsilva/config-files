<script setup lang="ts">
import { defineComponent } from 'vue'
import { IonPage, IonHeader, IonContent } from '@ionic/vue'
</script>

<template>
  <ion-page>
    <ion-header>
    </ion-header>
    <ion-content :fullscreen="true">
    </ion-content>
  </ion-page>
</template>

<style scoped></style>