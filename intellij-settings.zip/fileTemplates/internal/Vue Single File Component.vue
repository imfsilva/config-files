<script>
  export default {
    name: "${COMPONENT_NAME}"
  }
</script>

<template>
  <div></div>
</template>

<style scoped lang="scss"></style>